global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['6285608652644']
global.botname = 'VISION - RxhL - Botz [BETA]'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "VISION ARRIVED OFFICIAL"
global.sticker2 = "🌜"